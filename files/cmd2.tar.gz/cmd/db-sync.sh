#!/bin/sh 
sudo tar -xvf /home/ftp/dev/edu_el.tar.gz -C /home/mysql/mysql1/
