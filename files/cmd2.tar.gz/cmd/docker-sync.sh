#!/bin/sh 
rm -R /home/root1/docker
tar -zxvf /home/ftp/dev/docker.tar.gz
#mv /home/root1/cmd/docker /home/root1/docker
