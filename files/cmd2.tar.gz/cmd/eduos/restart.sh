#!/bin/sh 
python ~/docker/python/eduos_as.py app_restart 11
python ~/docker/python/eduos_as.py app_restart 12
