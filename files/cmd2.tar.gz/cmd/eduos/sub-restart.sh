#!/bin/sh 
python ~/docker/python/eduos_as.py app_restart 1
python ~/docker/python/eduos_as.py app_restart 2
