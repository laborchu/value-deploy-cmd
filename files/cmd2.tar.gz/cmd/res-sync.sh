#!/bin/sh 
tar -xvf /home/ftp/dev/res.tar.gz -C /home
