#!/bin/sh 
cd /home/res/elm/webapp/elm/elm
bower install
