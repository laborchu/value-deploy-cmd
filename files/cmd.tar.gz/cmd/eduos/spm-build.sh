#!/bin/bash 
cd /home/res/eduos/webapp/eduos/assets/script
sh b.sh
cd /home/res/eduos/webapp/eduos/ma/fsc
bower install
