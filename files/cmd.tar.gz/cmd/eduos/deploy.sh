#!/bin/bash 
rm -R /home/res/eduos/webapp/eduos
cp /home/ftp/dev/res/eduos/webapp/elos-web.war /home/res/eduos/webapp/eduos.war
unzip -oq /home/res/eduos/webapp/eduos.war -d /home/res/eduos/webapp/eduos
python ~/docker/python/eduos_as.py app_restart 1
#cd /home/res/eduos/webapp/eduos/assets/script
#sh b.sh
