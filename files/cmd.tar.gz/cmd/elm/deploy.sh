#!/bin/sh 
rm -R /home/res/elm/webapp/elm
cp /home/ftp/dev/res/eduos/webapp/elm-web.war /home/res/elm/webapp/elm.war
unzip -oq /home/res/elm/webapp/elm.war -d /home/res/elm/webapp/elm
python ~/docker/python/elm_as.py app_restart 1
~                      
